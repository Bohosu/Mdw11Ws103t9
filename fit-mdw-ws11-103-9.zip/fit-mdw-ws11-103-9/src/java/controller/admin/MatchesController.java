/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin;

import com.googlecode.objectify.Key;
import data.Competition;
import data.CompetitionDAO;
import data.Match;
import data.MatchDAO;
import data.PlayerDAO;
import data.SeasonDAO;
import data.Team;
import data.TeamDAO;
import java.io.IOException;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ondrej
 */
public class MatchesController {

    public static void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        MatchDAO dao = new MatchDAO();
        TeamDAO tdao = new TeamDAO();
        SeasonDAO sdao = new SeasonDAO();
        CompetitionDAO cdao = new CompetitionDAO();
        request.setAttribute("teams", tdao.getAll());
        request.setAttribute("cmps", cdao.getAll());
        request.setAttribute("seasons", sdao.getAllFetched());
        SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        if (action == null) {
            request.setAttribute("data", dao.getAll());
            request.setAttribute("teams", tdao.getAllFetched());
            request.setAttribute("cmps", cdao.getAllFetched());
        } else if (action.equals("delete")) {
            Long id = Long.parseLong(request.getParameter("id"));
            dao.delete(id);
            response.sendRedirect("/admin?section=matches");
        } else if (action.equals("new") && request.getMethod().equals("POST")) {
            Set errors = new HashSet<String>();
            Match s = new Match();
            String home = request.getParameter("home_team");
            String away = request.getParameter("away_team");
            String score = request.getParameter("score");
            String date = request.getParameter("date");
            String round = request.getParameter("round");
            String cmp = request.getParameter("competition");
            if (home == null || !home.matches("^\\d+$")) {
                errors.add("Špatný formát domácího týmu!");
            }
            if (away == null || !away.matches("^\\d+$")) {
                errors.add("Špatný formát domácího týmu!");
            }
            if (score != null && !score.isEmpty() && !score.matches("^\\d:\\d \\(\\d:\\d\\)$")) {
                errors.add("Špatný formát skóre!");
            }
            if (date == null || !date.matches("^\\d{2}\\.\\d{2}\\.\\d{4} \\d{2}:\\d{2}$")) {
                errors.add("Špatný formát data!");
            }
            if (round == null || !round.matches("^[0-9]+$")) {
                errors.add("Špatný formát kola!");
            }
            if (cmp == null || !cmp.matches("^\\d+$")) {
                errors.add("Špatný formát soutěže!");
            }
            if (errors.isEmpty()) {
                s.setHome_team(new Key(Team.class, Long.parseLong(home)));
                s.setAway_team(new Key(Team.class, Long.parseLong(away)));
                s.setCompetition(new Key(Competition.class, Long.parseLong(cmp)));
                s.setRound(Integer.parseInt(round));
                try {
                    s.setDate(df.parse(date));
                } catch (ParseException ex) {
                    Logger.getLogger(MatchesController.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (!score.isEmpty()) {
                    String[] sc = score.replaceAll("[()]", "").split("[ :]");
                    s.setGoals_home(Integer.parseInt(sc[0]));
                    s.setGoals_ht_home(Integer.parseInt(sc[2]));
                    s.setGoals_away(Integer.parseInt(sc[1]));
                    s.setGoals_ht_away(Integer.parseInt(sc[3]));
                    s.setPlayed(true);
                }
                dao.put(s);
                response.sendRedirect("/admin?section=matches");
            } else {
                request.setAttribute("errors", errors);
            }
        } else if (action.equals("edit")) {
            Long id = Long.parseLong(request.getParameter("id"));
            Match s = dao.get(id);
            if (request.getMethod().equals("POST")) {
                Set errors = new HashSet<String>();
                String home = request.getParameter("home_team");
                String away = request.getParameter("away_team");
                String score = request.getParameter("score");
                String date = request.getParameter("date");
                String round = request.getParameter("round");
                String cmp = request.getParameter("competition");
                if (home == null || !home.matches("^\\d+$")) {
                    errors.add("Špatný formát domácího týmu!");
                }
                if (away == null || !away.matches("^\\d+$")) {
                    errors.add("Špatný formát domácího týmu!");
                }
                if (score != null && !score.isEmpty() && !score.matches("^\\d:\\d \\(\\d:\\d\\)$")) {
                    errors.add("Špatný formát skóre!");
                }
                if (date == null || !date.matches("^\\d{2}\\.\\d{2}\\.\\d{4} \\d{2}:\\d{2}$")) {
                    errors.add("Špatný formát data!");
                }
                if (round == null || !round.matches("^[0-9]+$")) {
                    errors.add("Špatný formát kola!");
                }
                if (cmp == null || !cmp.matches("^\\d+$")) {
                    errors.add("Špatný formát soutěže!");
                }
                if (errors.isEmpty()) {
                    s.setHome_team(new Key(Team.class, Long.parseLong(home)));
                    s.setAway_team(new Key(Team.class, Long.parseLong(away)));
                    s.setCompetition(new Key(Competition.class, Long.parseLong(cmp)));
                    s.setRound(Integer.parseInt(round));
                    try {
                        s.setDate(df.parse(date));
                    } catch (ParseException ex) {
                        Logger.getLogger(MatchesController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (!score.isEmpty()) {
                        String[] sc = score.replaceAll("[()]", "").split("[ :]");
                        s.setGoals_home(Integer.parseInt(sc[0]));
                        s.setGoals_ht_home(Integer.parseInt(sc[2]));
                        s.setGoals_away(Integer.parseInt(sc[1]));
                        s.setGoals_ht_away(Integer.parseInt(sc[3]));
                        s.setPlayed(true);
                    } else {
                        s.setPlayed(false);
                    }
                    dao.put(s);
                    response.sendRedirect("/admin?section=matches");
                } else {
                    request.setAttribute("errors", errors);
                }
            }
            request.setAttribute("item", s);
            request.setAttribute("itemDate", df.format(s.getDate()));
            request.setAttribute("itemScore", s.getGoals_home() + ":" + s.getGoals_away() + " (" + s.getGoals_ht_home() + ":" + s.getGoals_ht_away() + ")");
        } else if (action.equals("squad")) {
            PlayerDAO pldao = new PlayerDAO();
            request.setAttribute("players", pldao.getAll());
        }
    }
}
