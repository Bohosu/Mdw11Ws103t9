/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller.front;

import com.googlecode.objectify.Key;
import data.Competition;
import data.CompetitionDAO;
import data.MatchDAO;
import data.SeasonDAO;
import data.TeamDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ondrej
 */
public class CompetitionsController {

    public static void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
        SeasonDAO sdao = new SeasonDAO();
        CompetitionDAO cdao = new CompetitionDAO();
        request.setAttribute("seasons", sdao.getAll());
        String season = request.getParameter("season");
        String cmp = request.getParameter("competition");
        if(cmp != null) {
            TeamDAO tdao = new TeamDAO();
            Competition c = cdao.get(Long.parseLong(cmp));
            season = "" + c.getSeason().getId();
            request.setAttribute("competition", c);
            request.setAttribute("teams", tdao.getAllFetched());
            String type = request.getParameter("type");
            MatchDAO mdao = new MatchDAO();
            if(type == null) {
            } else if(type.equals("stats")) {
            } else if(type.equals("schedule")) {
                request.setAttribute("schedule", mdao.query().filter("competition", new Key(Competition.class, c.getId())).list());
            } else if(type.equals("results")) {
                request.setAttribute("results", mdao.query().filter("played", true).filter("competition", new Key(Competition.class, c.getId())).list());
            }
        }
        if(season != null) {
            request.setAttribute("competitions", cdao.getAll());
        }
    }

}
