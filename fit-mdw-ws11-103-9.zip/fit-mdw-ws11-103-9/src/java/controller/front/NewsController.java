/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller.front;

import controller.admin.*;
import data.NewsDAO;
import data.News;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ondrej
 */
public class NewsController {

    public static void process(HttpServletRequest request, HttpServletResponse response) throws IOException {
        NewsDAO dao = new NewsDAO();
        request.setAttribute("data", dao.getAll());
        String id = (String)request.getParameter("id");
        if(id != null) {
            request.setAttribute("detail", dao.get(Long.parseLong(id)));
        }
    }

}
