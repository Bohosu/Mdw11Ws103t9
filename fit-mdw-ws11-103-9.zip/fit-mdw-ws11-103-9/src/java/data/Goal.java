/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data;

import com.googlecode.objectify.Key;
import javax.persistence.Id;

/**
 *
 * @author ondrej
 */
public class Goal {

    @Id
    private Long id;
    private int minute;
    Key<Player> scorer;
    Key<Player> asistent;

    public Goal(int minute, Key<Player> scorer, Key<Player> asistent) {
        this.minute = minute;
        this.scorer = scorer;
        this.asistent = asistent;
    }
    
}
