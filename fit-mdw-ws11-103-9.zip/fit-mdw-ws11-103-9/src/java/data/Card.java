/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data;

import com.googlecode.objectify.Key;
import javax.persistence.Id;

/**
 *
 * @author ondrej
 */
public class Card {

    @Id
    private Long id;
    private int minute;
    private CardColor type;
    Key<Player> player;

}
